﻿using System;
using System.Runtime.InteropServices;
using System.Threading;

public class Program
{
    // Importando as funções da user32.dll
    [DllImport("user32.dll")]
    static extern void mouse_event(uint dwFlags, uint dx, uint dy, uint dwData, IntPtr dwExtraInfo);

    [DllImport("user32.dll")]
    static extern short GetAsyncKeyState(int vKey);

    // Constantes para eventos de mouse
    const uint LEFTDOWN = 0x0002;
    const uint LEFTUP = 0x0004;

    // Tecla de atalho para ativar/desativar o autoclicker (Delete)
    const int HOTKEY = 0x2E; // Tecla Delete

    // Variáveis de controle
    static bool enableClicker = false; // Indica se o autoclicker está ativado
    static int averageClickInterval = 125; // Intervalo médio entre cliques (em milissegundos)
    static int randomIntervalRange = 10; // Variação aleatória em torno do intervalo médio (em milissegundos)

    static Random random = new Random();

    public static void Main()
    {
        // Loop principal
        while (true)
        {
            // Verifica se a tecla HOTKEY foi pressionada para ativar/desativar o autoclicker
            if (GetAsyncKeyState(HOTKEY) < 0)
            {
                enableClicker = !enableClicker; // Alterna o estado do autoclicker
                Thread.Sleep(300); // Pequeno delay entre usar a hotkey
            }

            // Se o autoclicker estiver ativado, realiza cliques
            if (enableClicker)
            {
                MouseClick();
            }

            // Calcula o próximo intervalo de clique com variação aleatória
            int nextClickInterval = averageClickInterval + random.Next(-randomIntervalRange, randomIntervalRange + 1);

            // Aguarda o tempo necessário antes de realizar o próximo clique
            Thread.Sleep(nextClickInterval);
        }
    }

    // Função para simular um clique do mouse
    static void MouseClick()
    {
        // Simula um clique do botão esquerdo do mouse
        mouse_event(LEFTDOWN, 0, 0, 0, IntPtr.Zero);
        Thread.Sleep(10); // Pequeno intervalo entre pressionar e soltar o botão do mouse
        mouse_event(LEFTUP, 0, 0, 0, IntPtr.Zero);
    }
}
